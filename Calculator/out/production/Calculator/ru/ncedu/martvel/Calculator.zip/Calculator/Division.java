package ru.ncedu.martvel.Calculator;

import java.math.BigDecimal;

public class Division {
    public double div(double arg1, double arg2) {
        return arg1 / arg2;
    }
}
