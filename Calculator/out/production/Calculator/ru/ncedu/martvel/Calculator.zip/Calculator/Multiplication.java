package ru.ncedu.martvel.Calculator;

public class Multiplication {
    public double mult(double arg1,double arg2) {
        return arg1 * arg2;
    }
}
