package ru.ncedu.martvel.Calculator;

public class Difference {
    public double minuse(double arg1,double arg2) {
        return arg1 - arg2;
    }
}
