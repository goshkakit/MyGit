package ru.ncedu.martvel.Calculator;

import static java.lang.Math.pow;

public class Exponentiation {
    public double inv(double arg1, double arg2){
        return pow(arg1,arg2);
    }
}
