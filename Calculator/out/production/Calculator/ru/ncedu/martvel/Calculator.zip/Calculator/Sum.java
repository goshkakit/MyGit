package ru.ncedu.martvel.Calculator;

public class Sum {
    public double plus(double arg1,double arg2){
        return arg1+arg2;
    }
}
